from django.db import models
import uuid


class user(models.Model):
    name=models.CharField(max_length=100, null=True)
    email=models.CharField(max_length=100, null=True)
    password=models.CharField(max_length=100, null=True)
    date_created = models.DateTimeField(auto_now_add=True, null=True)


class register(models.Model):
    user_id = models.UUIDField( default = uuid.uuid4,auto_created=True,primary_key=True,serialize=False,verbose_name='ID')
    name = models.CharField(max_length=100 , null=True) 
    email=models.CharField(max_length=100, null=True)
    password=models.CharField(max_length=100)
    password2=models.CharField(max_length=100)