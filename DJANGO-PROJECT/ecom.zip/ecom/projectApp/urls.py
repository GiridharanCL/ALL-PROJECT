from projectApp import views
from django.urls import path,include




urlpatterns = [
    path('Login/',views.loginpage,name='Login'),
    path('Register/',views.registerpage,name='Register'),
    path('', views.indexpage,name='index'),
    path('product/', views.productpage,name='product'),
    path('checkout/', views.checkoutpage,name='checkout'),
    path('wishlist/', views.wishlist,name='wishlist'),
    path('category/', views.category,name='category'),
    path('contact/', views.contact,name='contact'),
    
]