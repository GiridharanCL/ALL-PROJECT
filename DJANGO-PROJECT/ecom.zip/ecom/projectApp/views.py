from django.shortcuts import render,redirect
from .models import register

def loginpage(request):
     if request.method=='POST':
          email=request.POST.get('email')
          password=request.POST.get('password')
          
          my_user = list(register.objects.filter(email=email).values())[0]
          
          if password == my_user["password"]:
             request.session['email'] = email
             return render(request , 'projectApp/templates/index.html' ) 
     else:
               return render(request , 'projectApp/templates/Login.html' )
     

               
     

def registerpage(request):
     if request.method=='POST':
          name=request.POST.get('name')
          email=request.POST.get('email')
          password=request.POST.get('password')
          password2=request.POST.get('password2')
          my_register= register()
          my_register.name = name
          my_register.email = email
          my_register.password = password
          my_register.password2 = password2
          

          if request.POST.get('password') == request.POST.get('password2'):
             my_register.save()
             return render(request , 'projectApp/templates/Login.html' )
     else:
             print("Password mismatch")
             return render(request , 'projectApp/templates/Login.html' )
     
def indexpage(request):
     return render(request , 'projectApp/templates/index.html', )

def productpage(request):
     return render(request,'projectApp/templates/product.html')

def checkoutpage(request):
     return render(request , 'projectApp/templates/checkout.html')

def wishlist(request):
     return render(request , 'projectApp/templates/wishlist.html')

def category(request):
     return render(request , 'projectApp/templates/category-1.html')

def contact(request):
     return render(request , 'projectApp/templates/contact.html')