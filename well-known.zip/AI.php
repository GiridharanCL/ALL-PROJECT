<?php
$con=mysqli_connect('localhost','KRISH','KRISHtec@5747','entroll_form');
$res=mysqli_query($con,"select * from AI");
?>
<?php require 'auto_delete.php'?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>KRISHTEC</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="//cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="STYLE-ADMIN.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
</head>
<body>
    
	<!-- Banner -->


<!-- Dashboard -->
<div class="d-flex flex-column flex-lg-row h-lg-full bg-surface-secondary">
    <!-- Vertical Navbar -->
    <nav class="navbar show navbar-vertical h-lg-screen navbar-expand-lg px-0 py-3 navbar-light bg-white border-bottom border-bottom-lg-0 border-end-lg" id="navbarVertical">
        <div class="container-fluid">
            <!-- Toggler -->
            <button class="navbar-toggler ms-n2" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarCollapse" aria-controls="sidebarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- Brand -->
            <a class="navbar-brand py-lg-2 mb-lg-5 px-lg-6 me-0" href="#">
                   <img src="krish logo.PNG" alt="..." style="height:110px;">
            </a>
            <!-- User menu (mobile) -->
            <div class="navbar-user d-lg-none">
                <!-- Dropdown -->
                <div class="dropdown">
                    <!-- Toggle -->
                    <a href="#" id="sidebarAvatar" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <div class="avatar-parent-child">
                           
                        </div>
                    </a>
                    <!-- Menu -->
                    
                </div>
            </div>
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidebarCollapse">
                <!-- Navigation -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">
                            <i class="bi bi-house"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="KT.php">
                            <i class="bi bi-bar-chart"></i> Course
                        </a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="KT-CONTENT.php">
                            <i class="bi bi-bookmark-plus"></i> Course Content
                        </a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="Ai-database.php">
                            <i class="bi bi-people"></i> AI-Student's
                           
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="test.php">
                            <i class="bi bi-people"></i> IOT-Student's
                           
                        </a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="setting.php">
                          <i class="bi bi-person-plus"></i>Admin
                           
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">
                            <i class="bi bi-box-arrow-left"></i> Logout
                        </a>
                    </li>
                </ul>
                <!-- Divider -->
                
                <!-- Push content down -->
                
        </div>
    </nav>
    <!-- Main content -->
    <div class="h-screen flex-grow-1 overflow-y-lg-auto">
        <!-- Header -->
        <header class="bg-surface-primary border-bottom pt-6">
            <div class="container-fluid">
                <div class="mb-npx">
                    <div class="row align-items-center">
                        <div class="col-sm-6 col-12 mb-4 mb-sm-0">
                            <!-- Title -->
                            <h1 class="h2 mb-0 ls-tight"> ARTIFICIAL INTELLIGENCE</h1>
                        </div>
                        <ul class="navbar-nav mr-lg-4 w-50">
          <li class="nav-item nav-search d-none d-lg-block w-50">
            <div class="input-group" style="margin-left: 130%;width:60%;">
             
              
              <input type="text" class="form-control" placeholder="Search User" aria-label="search" aria-describedby="search" id='search-box'>
            </div>
          </li>
        </ul>
                       
                    </div>
                
                                    
                                    
                                   
                            
                            
                    <!-- Nav -->
                    <ul class="tabs">
                         <li class="tab" data-tab="tab-1">
                            <a href="KT.php" class="nav-link ">KT-NETWORK</a>
                        </li>
                        <li class="tab " data-tab="tab-2">
                            <a href="adas.php" class="nav-link ">ADAS (C++)</a>
                        </li>
                         <li class="tab " data-tab="tab-3">
                            <a href="adas-py.php" class="nav-link ">ADAS (PYTHON)</a>
                        </li>
                         <li class="tab " data-tab="tab-4">
                            <a href="rover(RPI).php" class="nav-link ">ADAS ROVER-(RPI)</a>
                        </li>
                         <li class="tab " data-tab="tab-5">
                            <a href="rover(JETSON NANO).php" class="nav-link ">ADAS ROVER-(JETSON NANO)</a>
                        </li>
                         <li class="tab current" data-tab="tab-6">
                            <a href="AI.php" class="nav-link ">AI</a>
                        </li>
                         <li class="tab " data-tab="tab-7">
                            <a href="DS.php" class="nav-link ">DATA SCIENCE</a>
                        </li>
                         
                    </ul>
                </div>
            </div>
        </header>
        <br>
      <style>
    .detail,.detail td,.detail th{
        border:1px solid black;
        border-collapse:collapse;
        padding:8px;
    }
    .detail{
        width:90%;
       margin-left:30px; 
        
    }
    .detail th{
        color:green;
    }
    .detail tr:nth-child(odd){
        background-color:#ddd;

    }
    .detail tr:nth-child(even){
        background-color:white;

    }



  .switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
.tabs {
  text-align: center;
  padding: 1.4rem;
}

ul.tabs li {
  position: relative;
  display: inline-block;
  text-transform: uppercase;
  /*padding: .8rem 2.4rem;
  background:#eee;*/
  cursor: pointer;
  margin: 0 1.1rem;
}

.tabs li:after {
  position: absolute;
  content: "";
  display: table;
  clear: both;
  left: 50%;
  width: 0;
  height: 2px;
  background: #45c;
  -webkit-transition: width 125ms ease, opacity 200ms ease;
  transition: width 125ms ease, opacity 200ms ease;
  -webkit-transform: translateX(-50%);
  transform: translateX(-50%);
}

.tabs li.current:after {
  opacity: 1;
  width: 100%;
}

ul.tabs li.current {
  font-weight: 600;
  color:#45c;
}
.tab-content {
  display: none;
    
}
.tab-content.current {
  display: inherit;
}

</style>

<table class="table table-bordered" id="example" style="margin-left:10px;">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">firstname</th>
      <th scope="col">lastname</th>
      <th scope="col">email</th>
        <th scope="col">college</th>
      <th scope="col">start date</th>
      <th scope="col">end date</th>
       <th scope="col">action</th>
       <th scope="col">user</th>
      
    </tr>
  </thead>
<tbody>
    
    <?php   
     $view = mysqli_query($con, "select * from AI ");
    while($data = mysqli_fetch_assoc($view)){ 
          $id = $data['id'];
          $firstname = $data['firstname'];
          $lastname = $data['lastname'];
          $email = $data['email'];
          $college = $data['college'];
          $date = $data['date'];
          $lastdate = $data['lastdate'];



          
      ?>

      <tr>
        <td><?php echo $id ; ?></td>
        <td><?php echo $firstname ; ?></td>
         <td><?php echo $lastname ; ?></td>
        <td><?php echo $email ; ?></td>
        <td><?php echo $college ; ?></td>
        <td><?php echo $date ; ?></td>
       <td><?php echo $lastdate;?> </td>
        
        <td>
          <?php 

           if($data['status']==1) {
             echo '<p><a href="Activate/AI-ACTIVE.php?id='.$data['id'].'&status=0" class="btn btn-success">Active</a></p>';
             
             
            
           }
           else
           {
            echo '<p><a href="Activate/AI-ACTIVE.php?id='.$data['id'].'&status=1" class="btn btn-danger">Deactive</a></p>';
           
           }

          ?>
        </td>
        
 <td>
           <?php echo "<a onclick=\" javascript:return confirm ('Are you Sure Delete This');  \" href='delete/AI-delete.php?id={$data['id']}' class='btn btn-secondary' ><i class='bi bi-trash'></i></a>" ?>
            
           
             </td>

          
          

      </tr>
    
  
   <?php  } ?>
  </tbody>
</table>
    
   </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" ></script>
 <script>
      (function () {
    var showResults;
    $('#search-box').keyup(function () {
        var searchText;
        searchText = $('#search-box').val();
        return showResults(searchText);
    });
    showResults = function (searchText) {
        $('tbody tr').hide();
        return $('tbody tr:Contains(' + searchText + ')').show();
    };
    jQuery.expr[':'].Contains = jQuery.expr.createPseudo(function (arg) {
        return function (elem) {
            return jQuery(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
        };
    });
}.call(this));
  </script>
  <script>
  $(document).ready( function () {
		$('.table').DataTable();
  });
  </script>
   <script>
      $('ul.tabs li').click(function() {
  var tab_id = $(this).attr('data-tab');
  $('ul.tabs li').removeClass('current');
  $('.tab-content').removeClass('current');
  $(this).addClass('current');
  $("#" + tab_id).addClass('current');
})
  </script>
</body>
</html>