<?php 
ob_start();
include_once("config.php");
session_start();
if(isset($_SESSION['Id'])!="") {
	header("Location: index.php");
}
if (isset($_POST['login'])) {
	$username = mysqli_real_escape_string($link, $_POST['username']);
	$password = mysqli_real_escape_string($link, $_POST['password']);
	$result = mysqli_query($link, "SELECT * FROM users WHERE username = '" . $username. "' and password = '" . $password. "'");
	if ($row = mysqli_fetch_array($result)) {
		$_SESSION['username'] = $row['username'];
		$_SESSION['password'] = $row['password'];		
		header("Location: home.php");
	} else {
		$error_message = "Incorrect Email or Password!!!";
	}
}
 
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="admin.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; 
            padding: 20px;
            border: 1px solid #ddd;
    margin: auto;
    margin-top: 15%; }
    </style>
</head>
<body>
   

    <div class="wrapper">
        <h2>Login</h2>
        <br>

        <?php 
        if(!empty($error_message)){
            echo '<div class="alert alert-danger">' . $error_message . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" >
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" name="login" class="btn btn-primary" value="Login">
            </div>
            
        </form>
    </div>
</body>
</html>