<?php 
ob_start();
include_once("config.php");
session_start();
if(isset($_SESSION['Id'])) {
	header("Location: setting.php");
}
$error = false;
if (isset($_POST['signup'])) {
	$username = mysqli_real_escape_string($link, $_POST['username']);
	$email = mysqli_real_escape_string($link, $_POST['email']);
	$password = mysqli_real_escape_string($link, $_POST['password']);
		

	if (!$error) {
		if(mysqli_query($link,"INSERT INTO users(username,email,password) VALUES('$username','$email','$password')")) {
			$_SESSION['message']= "New User Added Successfully!!! ";
		} else {
			$error_message = "Error in registering...Please try again later!";
		}
	}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KRISHTEC</title>
    <link rel="stylesheet" href="STYLE-ADMIN.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
</head>
<style>
    /* The Modal (background) */
.ebcf_modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.ebcf_modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 60%;
    margin-left:25%;
}

/* The Close Button */
.ebcf_close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.ebcf_close:hover,
.ebcf_close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}



@media screen and (max-width: 600px) {
 .input-group{
     display:none;
 }   
    
}

.detail,.detail td,.detail th{
        border:1px solid black;
        border-collapse:collapse;
        padding:8px;
    }
    .detail{
        width:90%;
       margin-left:30px; 
        
    }
    .detail th{
        color:green;
        background-color:white;
    }
    .detail tr:nth-child(odd){
        background-color:#F4F0F0;

    }
    .detail tr:nth-child(even){
        background-color:white;

    }
    
    @media screen and (max-width: 600px) {
  .table {
    border: 0;
    position:absolute;
  }

  .table caption {
    font-size: 1.3em;
  }
  
  .table thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  
  .table tr {
    border-bottom: 3px solid #ddd;
    display: block;
    margin-bottom: .625em;
  }
  
  .table td {
    border-bottom: 1px solid #ddd;
    display: block;
    font-size: .8em;
    text-align: right;
  }
  
  .table td::before {
    /*
    * aria-label has no advantage, it won't be read inside a table
    content: attr(aria-label);
    */
    content: attr(data-label);
    float: left;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  .table td:last-child {
    border-bottom: 0;
  }
}

@media screen and (max-width: 800px) {

.ebcf_modal-content{
   margin-top: 20%;
    width: 96%;
    margin-left: 2%;
}

}





</style>
<body>
    <!-- Banner -->


<!-- Dashboard -->
<div class="d-flex flex-column flex-lg-row h-lg-full bg-surface-secondary">
    <!-- Vertical Navbar -->
    <nav class="navbar show navbar-vertical h-lg-screen navbar-expand-lg px-0 py-3 navbar-light bg-white border-bottom border-bottom-lg-0 border-end-lg" id="navbarVertical">
        <div class="container-fluid">
            <!-- Toggler -->
            <button class="navbar-toggler ms-n2" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarCollapse" aria-controls="sidebarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- Brand -->
            <a class="navbar-brand py-lg-2 mb-lg-5 px-lg-6 me-0" href="#">
                <img src="krish logo.PNG" alt="..." style="height:110px;">
            </a>
            <!-- User menu (mobile) -->
            <div class="navbar-user d-lg-none">
                <!-- Dropdown -->
                <div class="dropdown">
                    <!-- Toggle -->
                    
                    <!-- Menu -->
                    
                </div>
            </div>
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidebarCollapse">
                <!-- Navigation -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">
                            <i class="bi bi-house"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="KT.php">
                            <i class="bi bi-bar-chart"></i> Course
                        </a>
                    </li>
                      <li class="nav-item">
                        <a class="nav-link" href="KT-CONTENT.php">
                            <i class="bi bi-bookmark-plus"></i> Course Content
                        </a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="Ai-database.php">
                            <i class="bi bi-people"></i> AI-Student's
                           
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="test.php">
                            <i class="bi bi-people"></i> IOT Student's
                           
                        </a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="setting.php">
                          <i class="bi bi-person-plus"></i>Admin
                           
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">
                            <i class="bi bi-box-arrow-left"></i> Logout
                        </a>
                    </li>
                </ul>
                <!-- Divider -->
                
                <!-- Push content down -->
                
        </div>
    </nav>
    <!-- Main content -->
    <div class="h-screen flex-grow-1 overflow-y-lg-auto">
        <!-- Header -->
        <header class="bg-surface-primary border-bottom pt-6">
            <div class="container-fluid">
                <div class="mb-npx">
                    <div class="row align-items-center">
                        <div class="col-sm-6 col-12 mb-4 mb-sm-0">
                            <!-- Title -->
                            <h1 class="h2 mb-0 ls-tight">User Account</h1>
                        </div>
                         <ul class="navbar-nav mr-lg-4 w-50">
          <li class="nav-item nav-search d-none d-lg-block w-50">
            <div class="input-group" style="margin-left: 74%;width:25%;">
             
              
              <input type="text" class="form-control" placeholder="Search now" aria-label="search" aria-describedby="search" id='search-box'>
            </div>
          </li>
        </ul><!-- Actions -->
                        
                    </div>
                    <!-- Nav -->
                   
        
       <br>
                </div>
            </div>
        </header>
        <!-- Main -->
        
        
        <br>
        
        
         
<button  class="btn btn-info" id="mySizeChart" style="margin-right:4%;float:right;">&nbsp;+ Add User</button>

<?php
        
        if(isset($_SESSION['message']))
        {
            
            ?>
            <div class="alert alert-success alert-dismissible">
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    <strong>Success!</strong>  <?php echo $_SESSION['message']; ?>
  </div>
            <?php 
            
           
            unset($_SESSION['message']);
        }
        ?>
     
<?php
        
        if(isset($_SESSION['status']))
        {
            
            ?>
            <div class="alert alert-danger alert-dismissible">
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    <strong>Caution!</strong>  <?php echo $_SESSION['status']; ?>
  </div>
            <?php 
            
           
            unset($_SESSION['status']);
        }
        ?>

<div id="mySizeChartModal" class="ebcf_modal">

  <div class="ebcf_modal-content">
    <span class="ebcf_close">&times;</span>
    
 
         <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
  <div class="form-group">
						<label for="name">Name</label>
						<input type="text" name="username" id="username" placeholder="Enter Full Name"  class="form-control" required class="form-control" />
						
					</div>
					
					<div class="form-group">
						<label for="name">Email</label>
						<input type="text" name="email" id="email" placeholder="Enter Your Email" class="form-control" required class="form-control"/>
						
					</div>

				

					<div class="form-group">
						<label for="name">Password</label>
						<input type="password" name="password" id="password" placeholder="Enter Your Password"  class="form-control" required class="form-control"/>
					
        
      
					</div>
					<input type="checkbox" onclick="myFunction()" style="margin-left:60%;"> &nbsp;<b>Show Password</b>
					<br>
 <div class="form-group">
						<input type="submit" name="signup" value="Submit" class="btn btn-primary" />
					</div>
  
</form>
 </div>

</div>

      
        <main class="py-6 bg-surface-secondary">
<br>



<br>


<table class="table table-bordered" id="example"  style="width:93%;margin-left:40px;">
  <thead >
    <tr>
      <th scope="col">ID</th>
      <th scope="col">USERNAME</th>
      <th scope="col">EMAIL</th>
        <th scope="col">PASSWORD</th>
      <th scope="col">CREATED_AT</th>
      <th scope="col">ACTION</th>
      
    </tr>
  </thead>
<tbody>
    
    <?php   
     $view = mysqli_query($link, "select * from users ");
    while($data = mysqli_fetch_assoc($view)){ 
          $id = $data['id'];
          $username = $data['username'];
          $email = $data['email'];
          $password = $data['password'];
           $created_at = $data['created_at'];
         


          
      ?>

      <tr>
        <td><?php echo $id ; ?></td>
        <td><?php echo $username ; ?></td>
        <td><?php echo $email ; ?></td>
        <td><?php echo $password ; ?></td>
        <td><?php echo $created_at ; ?></td>
     
        
       
        <td>
           <?php echo "<a onclick=\" javascript:return confirm ('Are you Sure Delete This');  \" href='delete1.php?id={$data['id']}' title='Delete' class='btn btn-secondary' ><i class='bi bi-trash'></i></a>" ?>
            <?php echo " <a class='btn btn-success' href='user-edit.php?id={$data['id']}'>Edit</a>" ?>
            
             </td>

          
             
      </tr>
    
    
  
   <?php  } ?>
  </tbody>
</table>
        </main>
        
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" ></script>
  <script src="//cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
  <script>
      // Get the modal
var ebModal = document.getElementById('mySizeChartModal');

// Get the button that opens the modal
var ebBtn = document.getElementById("mySizeChart");

// Get the <span> element that closes the modal
var ebSpan = document.getElementsByClassName("ebcf_close")[0];

// When the user clicks the button, open the modal 
ebBtn.onclick = function() {
    ebModal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
ebSpan.onclick = function() {
    ebModal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == ebModal) {
        ebModal.style.display = "none";
    }
}
  </script>
  
  <script>
      (function () {
    var showResults;
    $('#search-box').keyup(function () {
        var searchText;
        searchText = $('#search-box').val();
        return showResults(searchText);
    });
    showResults = function (searchText) {
        $('tbody tr').hide();
        return $('tbody tr:Contains(' + searchText + ')').show();
    };
    jQuery.expr[':'].Contains = jQuery.expr.createPseudo(function (arg) {
        return function (elem) {
            return jQuery(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
        };
    });
}.call(this));
  </script>
  <script>
function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
</body>
</html>