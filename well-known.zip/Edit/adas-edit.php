<?php
  include "../config.php";
  $id="";
  $topic="";
  $content="";
  

  $error="";
  $success="";

  if($_SERVER["REQUEST_METHOD"]=='GET'){
     if(!isset($_GET['id'])){
      header("location: ../ADAS-CONTENT.php");
      exit;
    }
    $id = $_GET['id'];
    $sql = "select * from Adas where id=$id";
    $result = $link->query($sql);
    $row = $result->fetch_assoc();
    while(!$row){
      header("location: ../ADAS-CONTENT.php");
      exit;
    }
    $topic=$row["topic"];
    $content=$row["content"];
   

  }
  else{
    $id = $_POST["id"];
    $topic=$_POST["topic"];
    $content=$_POST["content"];
   

    $sql = "UPDATE Adas SET topic='$topic', content='$content' WHERE id='$id'";
    $result = $link->query($sql);
    
    header("location: ../ADAS-CONTENT.php");
      exit;
  }
 
  
?>
<!DOCTYPE html>
<html>
<head>
 <title>KRISHTEC</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="../STYLE-ADMIN.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
</head>
<style>
    .card{
        padding:20px;
        
    }
    
    @media screen and (max-width: 800px) {

.card{
   margin-top: 20%;
    width: 96%;
    margin-left: 2%;
    margin-top:-11%;
}
.form-group{
    width:100%;
}

}
</style>
<body>

<div class="d-flex flex-column flex-lg-row h-lg-full bg-surface-secondary">
    <!-- Vertical Navbar -->
    <nav class="navbar show navbar-vertical h-lg-screen navbar-expand-lg px-0 py-3 navbar-light bg-white border-bottom border-bottom-lg-0 border-end-lg" id="navbarVertical">
        <div class="container-fluid">
            <!-- Toggler -->
            <button class="navbar-toggler ms-n2" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarCollapse" aria-controls="sidebarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- Brand -->
            <a class="navbar-brand py-lg-2 mb-lg-5 px-lg-6 me-0" href="#">
                <img src="../krish logo.PNG" alt="..." style="height:110px;">
            </a>
            <!-- User menu (mobile) -->
            <div class="navbar-user d-lg-none">
                <!-- Dropdown -->
                <div class="dropdown">
                    <!-- Toggle -->
                    
                    <!-- Menu -->
                    
                </div>
            </div>
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidebarCollapse">
                <!-- Navigation -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../home.php">
                            <i class="bi bi-house"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../KT.php">
                            <i class="bi bi-bar-chart"></i> Course
                        </a>
                    </li>
                      <li class="nav-item">
                        <a class="nav-link" href="../KT-CONTENT.php">
                            <i class="bi bi-bookmark-plus"></i> Course Content
                        </a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="../Ai-database.php">
                            <i class="bi bi-people"></i> AI-Student's
                           
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../test.php">
                            <i class="bi bi-people"></i> IOT Student's
                           
                        </a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="../setting.php">
                          <i class="bi bi-person-plus"></i>Admin
                           
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">
                            <i class="bi bi-box-arrow-left"></i> Logout
                        </a>
                    </li>
                </ul>
                <!-- Divider -->
                
                <!-- Push content down -->
                
        </div>
    </nav>
    <!-- Main content -->
    <div class="h-screen flex-grow-1 overflow-y-lg-auto">
        <!-- Header -->
        <header class="bg-surface-primary border-bottom pt-6">
            <div class="container-fluid">
                <div class="mb-npx">
                    <div class="row align-items-center">
                        <div class="col-sm-6 col-12 mb-4 mb-sm-0">
                            <!-- Title -->
                            <h1 class="h2 mb-0 ls-tight">ADAS(C++)</h1>
                        </div>
                         <ul class="navbar-nav mr-lg-4 w-50">
          <li class="nav-item nav-search d-none d-lg-block w-50">
            <div class="input-group" style="margin-left: 300%;width:85%;">
             
              
              <input type="text" class="form-control" placeholder="Search now" aria-label="search" aria-describedby="search" id='search-box'>
            </div>
          </li>
        </ul><!-- Actions -->
                        
                    </div>
                    <!-- Nav -->
                   
        
       <br>
                </div>
            </div>
        </header>
        <!-- Main -->
        
        
        <br>
        
        
 <div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div class="card-header ">
 <h1 class="text-blue text-center">  Update Content </h1>
 </div><br>

 <input type="hidden" name="id" value="<?php echo $id; ?>" class="form-control"> <br>
<div class="form-group">
 <label> Topic: </label>
 <input type="text" name="topic"  id="topic" value="<?php echo $topic; ?>" class="form-control"> <br>

</div>


<div class="form-group">
 <label> Content: </label>
 <input type="text" name="content" id="content" value="<?php echo $content; ?>" class="form-control"> <br>
</div>




<div class="col-12 sm-6 "  style="margin-left:25%;">
 <button class="btn btn-success" type="submit" name="update"> Update </button>
 
 

 <button><a class="btn btn-info" type="submit" name="cancel" href="../ADAS-CONTENT.php"> Cancel </a></button>
</div>
 </div>
 </form>
 </div>
 </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" ></script>
  <script src="//cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
  <script>
      // Get the modal
var ebModal = document.getElementById('mySizeChartModal');

// Get the button that opens the modal
var ebBtn = document.getElementById("mySizeChart");

// Get the <span> element that closes the modal
var ebSpan = document.getElementsByClassName("ebcf_close")[0];

// When the user clicks the button, open the modal 
ebBtn.onclick = function() {
    ebModal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
ebSpan.onclick = function() {
    ebModal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == ebModal) {
        ebModal.style.display = "none";
    }
}
  </script>
  
  <script>
      (function () {
    var showResults;
    $('#search-box').keyup(function () {
        var searchText;
        searchText = $('#search-box').val();
        return showResults(searchText);
    });
    showResults = function (searchText) {
        $('tbody tr').hide();
        return $('tbody tr:Contains(' + searchText + ')').show();
    };
    jQuery.expr[':'].Contains = jQuery.expr.createPseudo(function (arg) {
        return function (elem) {
            return jQuery(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
        };
    });
}.call(this));
  </script>
  <script>
function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
</body>
</html>