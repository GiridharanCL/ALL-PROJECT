<?php
/*session_start();*/
$servername = "localhost";
$username = "KRISH";
$password = "KRISHtec@5747";
$database ="entroll_form";

//create connection

$con = mysqli_connect($servername,$username,$password,$database);
//check connectioin
if ($con) {
	/*echo " Database Connected Successfully";*/
}
else{
	die("connection faild:".mysqli_connect_error());
}


 ?>