<?php 
$con=new mysqli('localhost','COVAILABS','KRISHtec','login_form');

if($_GET['id'])
{
    $id=$_GET['id'];
    $sql="DELETE FROM login_details WHERE id='$id'";
    
    $result = mysqli_query($con,$sql);
    
   
    if($result)
    {
        
        header("location: Ai-database.php");
    }
    
    
}

?>