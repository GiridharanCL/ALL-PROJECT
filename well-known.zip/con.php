<?php 
 
 $con = mysqli_connect("localhost","KRISHTEC","KRISHtec@5747","Iot-login") or die("Couldn't connect");

?>