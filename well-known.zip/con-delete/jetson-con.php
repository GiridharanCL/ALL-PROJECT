<?php 
include "../config.php";

if($_GET['id'])
{
    $id=$_GET['id'];
    $sql="DELETE FROM Jetsonnano WHERE id='$id'";
    $result = mysqli_query($link,$sql);
    
    if($result)
    {
        header("location: ../JETSONNANO-CONTENT.php");
    }
    
    
}



?>