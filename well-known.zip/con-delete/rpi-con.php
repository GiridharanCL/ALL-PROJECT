<?php 
include "../config.php";

if($_GET['id'])
{
    $id=$_GET['id'];
    $sql="DELETE FROM Rpi WHERE id='$id'";
    $result = mysqli_query($link,$sql);
    
    if($result)
    {
        header("location: ../RPI-CONTENT.php");
    }
    
    
}



?>