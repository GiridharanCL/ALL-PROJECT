<?php 
include "../config.php";

if($_GET['id'])
{
    $id=$_GET['id'];
    $sql="DELETE FROM Ds WHERE id='$id'";
    $result = mysqli_query($link,$sql);
    
    if($result)
    {
        header("location: ../DS-CONTENT.php");
    }
    
    
}



?>