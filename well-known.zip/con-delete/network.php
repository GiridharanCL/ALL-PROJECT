<?php 
include "../config.php";

if($_GET['id'])
{
    $id=$_GET['id'];
    $sql="DELETE FROM Network WHERE id='$id'";
    $result = mysqli_query($link,$sql);
    
    if($result)
    {
        header("location: ../KT-CONTENT.php");
    }
    
    
}



?>

