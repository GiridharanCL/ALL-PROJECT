<?php
	date_default_timezone_set("Etc/GMT+8");
	
	require_once 'db.php';
	
	$view = mysqli_query($con, "SELECT * FROM `KIT`");
	$lastdate = date("Y-m-d");
while($data = mysqli_fetch_assoc($view)){
		if($data['lastdate'] == $lastdate){
		    
			mysqli_query($con, "DELETE FROM `KIT` WHERE NOW() > lastdate");
		
		}
	}
	
	
?>

<?php
	date_default_timezone_set("Etc/GMT+8");
	
	require_once 'db.php';
	
	$view = mysqli_query($con, "SELECT * FROM `ADAS`");
	$lastdate = date("Y-m-d");
while($data = mysqli_fetch_assoc($view)){
		if($data['lastdate'] == $lastdate){
		    
			mysqli_query($con, "DELETE FROM `ADAS` WHERE NOW() > lastdate");
		
		}
	}
	
	
?>

<?php
	date_default_timezone_set("Etc/GMT+8");
	
	require_once 'db.php';
	
	$view = mysqli_query($con, "SELECT * FROM `PYTHON`");
	$lastdate = date("Y-m-d");
while($data = mysqli_fetch_assoc($view)){
		if($data['lastdate'] == $lastdate){
		    
			mysqli_query($con, "DELETE FROM `PYTHON` WHERE NOW() > lastdate");
		
		}
	}
	
	
?>

<?php
	date_default_timezone_set("Etc/GMT+8");
	
	require_once 'db.php';
	
	$view = mysqli_query($con, "SELECT * FROM `RPI`");
	$lastdate = date("Y-m-d");
while($data = mysqli_fetch_assoc($view)){
		if($data['lastdate'] == $lastdate){
		    
			mysqli_query($con, "DELETE FROM `RPI` WHERE NOW() > lastdate");
			
		}
	}
	
	
?>

<?php
	date_default_timezone_set("Etc/GMT+8");
	
	require_once 'db.php';
	
	$view = mysqli_query($con, "SELECT * FROM `JETSONNANO`");
	$lastdate = date("Y-m-d");
while($data = mysqli_fetch_assoc($view)){
		if($data['lastdate'] == $lastdate){
		    
			mysqli_query($con, "DELETE FROM `JETSONNANO` WHERE NOW() > lastdate");
			
		}
	}
	
	
?>
<?php
	date_default_timezone_set("Etc/GMT+8");
	
	require_once 'db.php';
	
	$view = mysqli_query($con, "SELECT * FROM `AI`");
	$lastdate = date("Y-m-d");
while($data = mysqli_fetch_assoc($view)){
		if($data['lastdate'] == $lastdate){
		    
			mysqli_query($con, "DELETE FROM `AI` WHERE NOW() > lastdate");
		
		}
	}
	
	
?>
<?php
	date_default_timezone_set("Etc/GMT+8");
	
	require_once 'db.php';
	
	$view = mysqli_query($con, "SELECT * FROM `DATASCIENCE`");
	$lastdate = date("Y-m-d");
while($data = mysqli_fetch_assoc($view)){
		if($data['lastdate'] == $lastdate){
		    
			mysqli_query($con, "DELETE FROM `DATASCIENCE` WHERE NOW() > lastdate");
			
		}
	}
	
	
?>