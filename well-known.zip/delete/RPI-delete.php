<?php 
include "../db.php";

if($_GET['id'])
{
    $id=$_GET['id'];
    $sql="DELETE FROM RPI WHERE id='$id'";
    $result = mysqli_query($con,$sql);
    
    if($result)
    {
        header("location: ../rover(RPI).php");
    }
    
    
}



?>