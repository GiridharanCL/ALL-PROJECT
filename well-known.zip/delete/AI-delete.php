<?php 
include "../db.php";

if($_GET['id'])
{
    $id=$_GET['id'];
    $sql="DELETE FROM AI WHERE id='$id'";
    $result = mysqli_query($con,$sql);
    
    if($result)
    {
        header("location: ../AI.php");
    }
    
    
}



?>