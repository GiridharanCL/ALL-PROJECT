<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KRISHTEC</title>
    <link rel="stylesheet" href="STYLE-ADMIN.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
</head>
<body>
    <!-- Banner -->


<!-- Dashboard -->
<div class="d-flex flex-column flex-lg-row h-lg-full bg-surface-secondary">
    <!-- Vertical Navbar -->
    <nav class="navbar show navbar-vertical h-lg-screen navbar-expand-lg px-0 py-3 navbar-light bg-white border-bottom border-bottom-lg-0 border-end-lg" id="navbarVertical">
        <div class="container-fluid">
            <!-- Toggler -->
            <button class="navbar-toggler ms-n2" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarCollapse" aria-controls="sidebarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- Brand -->
            <a class="navbar-brand py-lg-2 mb-lg-5 px-lg-6 me-0" href="#">
                  <img src="krish logo.PNG" alt="..." style="height:110px;">
            </a>
            <!-- User menu (mobile) -->
            <div class="navbar-user d-lg-none">
                <!-- Dropdown -->
                <div class="dropdown">
                    <!-- Toggle -->
                    <a href="#" id="sidebarAvatar" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <div class="avatar-parent-child">
                           
                        </div>
                    </a>
                    <!-- Menu -->
                    
                </div>
            </div>
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidebarCollapse">
                <!-- Navigation -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">
                            <i class="bi bi-house"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="KT.php">
                            <i class="bi bi-bar-chart"></i> Course
                        </a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="KT-CONTENT.php">
                            <i class="bi bi-bookmark-plus"></i> Course Content
                        </a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="">
                            <i class="bi bi-people"></i> AI-Student's
                           
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="test.php">
                            <i class="bi bi-people"></i> IOT-Student's 
                           
                        </a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="setting.php">
                          <i class="bi bi-person-plus"></i>Admin
                           
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">
                            <i class="bi bi-box-arrow-left"></i> Logout
                        </a>
                    </li>
                </ul>
                <!-- Divider -->
                
                <!-- Push content down -->
                
        </div>
    </nav>
    <!-- Main content -->
    <div class="h-screen flex-grow-1 overflow-y-lg-auto">
        <!-- Header -->
        <header class="bg-surface-primary border-bottom pt-6">
            <div class="container-fluid">
                <div class="mb-npx">
                    <div class="row align-items-center">
                        <div class="col-sm-6 col-12 mb-4 mb-sm-0">
                            <!-- Title -->
                            <h1 class="h2 mb-0 ls-tight">AI-Students Table</h1>
                        </div>
                        <!-- Actions -->
                       
                    </div>
                    <!-- Nav -->
                   <ul class="navbar-nav mr-lg-4 w-50">
          <li class="nav-item nav-search d-none d-lg-block w-50">
            <div class="input-group" style="margin-left: 74%;width:25%;">
             
              
              <input type="text" class="form-control" placeholder="Search now" aria-label="search" aria-describedby="search" id='search-box' >
            </div>
          </li>
        </ul>
        
       <br>
                </div>
            </div>
        </header>
        <br>
<style>
    .detail,.detail td,.detail th{
        border:1px solid black;
        border-collapse:collapse;
        padding:8px;
    }
    .detail{
        width:90%;
       margin-left:30px; 
        
    }
    .detail th{
        color:green;
         background-color:white;
    }
    .detail tr:nth-child(odd){
        background-color:#F4F0F0;

    }
    .detail tr:nth-child(even){
        background-color:white;

    }


@media only screen and (max-width:720px){
 .detail{
     width:100%;
     margin-left:-10px;
 }   
    
}


@media screen and (max-width: 600px) {
  .table {
    border: 0;
  }

  .table caption {
    font-size: 1.3em;
  }
  
  .table thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  
  .table tr {
    border-bottom: 3px solid #ddd;
    display: block;
    margin-bottom: .625em;
  }
  
  .table td {
    border-bottom: 1px solid #ddd;
    display: block;
    font-size: .8em;
    text-align: right;
  }
  
  .table td::before {
    /*
    * aria-label has no advantage, it won't be read inside a table
    content: attr(aria-label);
    */
    content: attr(data-label);
    float: left;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  .table td:last-child {
    border-bottom: 0;
  }
}


@media screen and (max-width: 600px) {
    .input-group .form-control{
        width:20%;
        top:1px;
    }
    
}
</style>

<?php
error_reporting(0);
$con=new mysqli('localhost','COVAILABS','KRISHtec','login_form');

?>



<table class="table table-bordered" id="example" style="width:93%;margin-left:40px;">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">USERNAME</th>
      <th scope="col">EMAIL</th>
      <th scope="col">ACTION</th>
      
    </tr>
  </thead>
<tbody>
    
    <?php   
     $view = mysqli_query($con, "select * from login_details ");
    while($data = mysqli_fetch_assoc($view)){ 
          $id = $data['id'];
          $user_name = $data['user_name'];
          $email = $data['email'];
         
          
         


          
      ?>

      <tr>
        <td><?php echo $id ; ?></td>
        <td><?php echo $user_name ; ?></td>
        <td><?php echo $email ; ?></td>
        
     
        
       
        <td>
           <?php echo "<a onclick=\" javascript:return confirm ('Are you Sure Delete This');  \" href='ai-delete.php?id={$data['id']}' class='btn btn-secondary' ><i class='bi bi-trash'></i></a>" ?>
            
            
             </td>

          
             
      </tr>
    
  
   <?php  } ?>
  </tbody>
</table>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" ></script>
  <script src="//cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
  
  <script>
      (function () {
    var showResults;
    $('#search-box').keyup(function () {
        var searchText;
        searchText = $('#search-box').val();
        return showResults(searchText);
    });
    showResults = function (searchText) {
        $('tbody tr').hide();
        return $('tbody tr:Contains(' + searchText + ')').show();
    };
    jQuery.expr[':'].Contains = jQuery.expr.createPseudo(function (arg) {
        return function (elem) {
            return jQuery(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
        };
    });
}.call(this));
  </script>
</body>
</html>