<?php 
session_start();
include('config.php');

if($_GET['id'])
{
    $id=$_GET['id'];
    $sql="DELETE FROM users WHERE id='$id'";
    $result = mysqli_query($link,$sql);
    
   
    if($result)
    {
         $_SESSION['status']= "Data Is Deleted Successfully ";
        header('location: setting.php');
    }
    
    
}

?>
