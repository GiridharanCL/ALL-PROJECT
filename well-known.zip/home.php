<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KRISHTEC</title>
    <link rel="stylesheet" href="STYLE-ADMIN.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
    <!-- Option 1: Include in HTML -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
</head>
<style>
    .detail,.detail td,.detail th{
        border:1px solid black;
        border-collapse:collapse;
        padding:8px;
    }
    .detail{
        width:90%;
       margin-left:30px; 
        
    }
    .detail th{
        color:green;
    }
    .detail tr:nth-child(odd){
        background-color:#ddd;

    }
    .detail tr:nth-child(even){
        background-color:white;

    }


@media only screen and (max-width:992px){
 .detail{
     position:absolute;
     width:3%;
 }   
    
}


@media screen and (max-width: 600px) {
  .table {
    border: 0;
  }

  .table caption {
    font-size: 1.3em;
  }
  
  .table thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  
  .table tr {
    border-bottom: 3px solid #ddd;
    display: block;
    margin-bottom: .625em;
  }
  
  .table td {
    border-bottom: 1px solid #ddd;
    display: block;
    font-size: .8em;
    text-align: right;
  }
  
  .table td::before {
    /*
    * aria-label has no advantage, it won't be read inside a table
    content: attr(aria-label);
    */
    content: attr(data-label);
    float: left;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  .table td:last-child {
    border-bottom: 0;
  }
  
}

.canvasjs-chart-credit{
    display:none;
}





</style>

<body>
    <!-- Banner -->


<!-- Dashboard -->
<div class="d-flex flex-column flex-lg-row h-lg-full bg-surface-secondary">
    <!-- Vertical Navbar -->
    <nav class="navbar show navbar-vertical h-lg-screen navbar-expand-lg px-0 py-3 navbar-light bg-white border-bottom border-bottom-lg-0 border-end-lg" id="navbarVertical">
        <div class="container-fluid">
            <!-- Toggler -->
            <button class="navbar-toggler ms-n2" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarCollapse" aria-controls="sidebarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- Brand -->
            <a class="navbar-brand py-lg-2 mb-lg-5 px-lg-6 me-0" href="#">
                <img src="krish logo.PNG" alt="..." style="height:110px;">
            </a>
            <!-- User menu (mobile) -->
            <div class="navbar-user d-lg-none">
                <!-- Dropdown -->
                <div class="dropdown">
                    <!-- Toggle -->
                    
                    <!-- Menu -->
                    
                </div>
            </div>
            <!-- Collapse -->
            <div class="collapse navbar-collapse" id="sidebarCollapse">
                <!-- Navigation -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="home.php">
                            <i class="bi bi-house"></i> Dashboard
                        </a>
                    </li>
                    
                    



  
                    <li class="nav-item">
                        <a class="nav-link" href="KT.php">
                            <i class="bi bi-bar-chart"></i> Course
                        </a>
                    </li>
                    
                     <li class="nav-item">
                        <a class="nav-link" href="KT-CONTENT.php">
                            <i class="bi bi-bookmark-plus"></i> Course Content
                        </a>
                    </li>
                     
                     <li class="nav-item">
                        <a class="nav-link" href="Ai-database.php">
                            <i class="bi bi-people"></i> AI-Student's
                           
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="test.php">
                            <i class="bi bi-people"></i> IOT Student's
                           
                        </a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="setting.php">
                          <i class="bi bi-person-plus"></i>Admin
                           
                        </a>
                    </li>
                   
                   
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">
                            <i class="bi bi-box-arrow-left"></i> Logout
                        </a>
                    </li>
                </ul>
                <!-- Divider -->
                
                <!-- Push content down -->
                
        </div>
    </nav>
    <div class="msb" id="msb">
	
</div>
    <!-- Main content -->
    <div class="h-screen flex-grow-1 overflow-y-lg-auto">
        <!-- Header -->
        <header class="bg-surface-primary border-bottom pt-6">
            <div class="container-fluid">
                <div class="mb-npx">
                    <div class="row align-items-center">
                        <div class="col-sm-6 col-12 mb-4 mb-sm-0">
                            <!-- Title -->
                            <h1 class="h2 mb-0 ls-tight">Dashboard</h1>
                        </div>
                        <!-- Actions -->
                        
                    </div>
                    <!-- Nav -->
                    <ul class="navbar-nav mr-lg-4 w-50">
          <li class="nav-item nav-search d-none d-lg-block w-50">
            <div class="input-group" style="margin-left: 74%;width:25%;">
             
              
              <input type="text" class="form-control" placeholder="Search now" aria-label="search" aria-describedby="search" id='search-box'>
            </div>
          </li>
        </ul>
        
       <br>
                </div>
            </div>
        </header>
        <!-- Main -->
        <main class="py-6 bg-surface-secondary">
            <div class="container-fluid">
                <!-- Card stats -->
                <div class="row g-6 mb-6">
                    <div class="col-xl-4 col-sm-6 col-12">
                        <div class="card shadow border-0">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <span class="h6 font-semibold text-muted text-sm d-block mb-2">AI- Student's</span>
                                      
                                        <?php
                                            error_reporting(0);
                                            $con=new mysqli('localhost','COVAILABS','KRISHtec','login_form');
                                            if($con->connect_errno)
                                            {
                                                echo $con->connect_error;
                                                die();
                                            }
                                            $query= "SELECT Id FROM login_details";
                                            $query_run = mysqli_query($con,$query);
                                            
                                            $row = mysqli_num_rows($query_run);
                                            
                                            echo '<h3>'.$row.'</h3>'
                                        
                                        ?>
                                        
                                       
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-primary text-white text-lg rounded-circle">
                                           <i class="bi bi-people"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="mt-2 mb-0 text-sm">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-sm-6 col-12">
                        <div class="card shadow border-0">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <span class="h6 font-semibold text-muted text-sm d-block mb-2">IOT- Student's</span>
                                         <?php
                                            error_reporting(0);
                                            $con=new mysqli('localhost','KRISHTEC','KRISHtec@5747','Iot-login');
                                            if($con->connect_errno)
                                            {
                                                echo $con->connect_error;
                                                die();
                                            }
                                            $query= "SELECT Id FROM users";
                                            $query_run = mysqli_query($con,$query);
                                            
                                            $row = mysqli_num_rows($query_run);
                                            
                                            echo '<h3>'.$row.'</h3>'
                                        
                                        ?>
                                        
                                        
                                        
                                        
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-primary text-white text-lg rounded-circle">
                                            <i class="bi bi-people"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="mt-2 mb-0 text-sm">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-sm-6 col-12">
                        <div class="card shadow border-0">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col">
                                        <span class="h6 font-semibold text-muted text-sm d-block mb-2"> Approved</span>
                                         
                                         
                                         <?php
                                            error_reporting(0);
                                            $con=new mysqli('localhost','KRISH','KRISHtec@5747','entroll_form');
                                            if($con->connect_errno)
                                            {
                                                echo $con->connect_error;
                                                die();
                                            }
                                            $query_KIT= "SELECT status FROM KIT WHERE status=1";
                                            $query_run1 = mysqli_query($con,$query_KIT);
                                            
                                            $row_KIT = mysqli_num_rows($query_run1);
                                            
                                            $query_adas= "SELECT status FROM ADAS WHERE status=1";
                                            $query_run1 = mysqli_query($con,$query_adas);
                                            
                                            $row_adas = mysqli_num_rows($query_run1);
                                            
                                            $query_PYTHON= "SELECT status FROM PYTHON WHERE status=1";
                                            $query_run2 = mysqli_query($con,$query_PYTHON);
                                            
                                            $row_PYTHON = mysqli_num_rows($query_run2);
                                            
                                            $query_RPI= "SELECT status FROM RPI WHERE status=1";
                                            $query_run3 = mysqli_query($con,$query_RPI);
                                            
                                            $row_RPI = mysqli_num_rows($query_run3);
                                            
                                            
                                            $query_JETSONNANO= "SELECT status FROM JETSONNANO WHERE status=1";
                                            $query_run4 = mysqli_query($con,$query_JETSONNANO);
                                            
                                            $row_JETSONNANO = mysqli_num_rows($query_run4);
                                            
                                            
                                            $query_AI= "SELECT status FROM AI WHERE status=1";
                                            $query_run5 = mysqli_query($con,$query_AI);
                                            
                                            $row_AI = mysqli_num_rows($query_run5);
                                            
                                            
                                            
                                            
                                            $query_DATASCIENCE= "SELECT status FROM DATASCIENCE WHERE status=1";
                                            $query_run6 = mysqli_query($con,$query_DATASCIENCE);
                                            
                                            $row_DATASCIENCE = mysqli_num_rows($query_run6);
                                            
                                            
                                            $row = $row_KIT + $row_adas + $row_PYTHON + $row_RPI + $row_JETSONNANO + $row_AI + $row_DATASCIENCE ;
                                            
                                            echo '<h3>'.$row.'</h3>'
                                        
                                        ?>
                                        
                                        
                                    </div>
                                    <div class="col-auto">
                                        <div class="icon icon-shape bg-info text-white text-lg rounded-circle">
                                            <i class="bi-check-circle"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="mt-2 mb-0 text-sm">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <?php
  $con = mysqli_connect("localhost","KRISH","KRISHtec@5747","entroll_form");
  
  
  
  
  
  $sql = "SELECT * from ADAS";

if ($result = mysqli_query($con, $sql)) {

    // Return the number of rows in result set
    $rowcount = mysqli_num_rows( $result );
    
    
   
 }
 
 
 $sql = "SELECT * from PYTHON";

if ($result = mysqli_query($con, $sql)) {

    // Return the number of rows in result set
    $rowcount1 = mysqli_num_rows( $result );
    
    
    
 }
 
 
 $sql = "SELECT * from RPI";

if ($result = mysqli_query($con, $sql)) {

    // Return the number of rows in result set
    $rowcount2 = mysqli_num_rows( $result );
    
    
     
 }
 
 $sql = "SELECT * from JETSONNANO";

if ($result = mysqli_query($con, $sql)) {

    // Return the number of rows in result set
    $rowcount3 = mysqli_num_rows( $result );
    
    
    
 }
 $sql = "SELECT * from AI";

if ($result = mysqli_query($con, $sql)) {

    // Return the number of rows in result set
    $rowcount4 = mysqli_num_rows( $result );
    
    
     
 }
 $sql = "SELECT * from DATASCIENCE";

if ($result = mysqli_query($con, $sql)) {

    // Return the number of rows in result set
    $rowcount5 = mysqli_num_rows( $result );
    
    
     
 }
 
 $sql = "SELECT * from KIT";

if ($result = mysqli_query($con, $sql)) {

    // Return the number of rows in result set
    $rowcount6 = mysqli_num_rows( $result );
    
    
   
 }
 

       
       
      
       

?>  



               
          
          
         
          <?php
 
$dataPoints = array( 
	array("label"=>"ADAS" , "y"=>"$rowcount"),
	array("label"=>"PYTHON", "y"=>"$rowcount1"),
	array("label"=>"RPI", "y"=>"$rowcount2"),
	array("label"=>"JETSON NANO", "y"=>"$rowcount3"),
	array("label"=>"AI", "y"=>"$rowcount4"),
	array("label"=>"DATA SCIENCE", "y"=>"$rowcount5"),
    array("label"=>"NETWORK KIT", "y"=>"$rowcount6")
)
 
?>

<script>
window.onload = function() {
 
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		text: "KRISHTEC-COURSE CHART"
	},
	subtitles: [{
	
	}],
	data: [{
		type: "pie",
		yValueFormatString: "#,##0",
		indexLabel: "{label} ({y})",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();

}
</script>
</head>

<div id="chartContainer" style="height: 400px; width: 90%;"></div>
<script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>
     
 
            
 </div>
            </div>
        </main>
  
        
    </div>
</div>
 <script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" ></script>
  <script src="//cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
 <script>
     (function(){
  $('#msbo').on('click', function(){
    $('body').toggleClass('msb-x');
  });
}());
 </script>
 
  <script>
      (function () {
    var showResults;
    $('#search-box').keyup(function () {
        var searchText;
        searchText = $('#search-box').val();
        return showResults(searchText);
    });
    showResults = function (searchText) {
        $('text').hide();
        return $('text:Contains(' + searchText + ')').show();
    };
    jQuery.expr[':'].Contains = jQuery.expr.createPseudo(function (arg) {
        return function (elem) {
            return jQuery(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
        };
    });
}.call(this));
  </script>
  
</body>
</html>